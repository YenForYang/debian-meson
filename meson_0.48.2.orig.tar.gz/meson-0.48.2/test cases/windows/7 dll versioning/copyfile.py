#!/usr/bin/env python3

import sys
import shutil

shutil.copyfile(sys.argv[1], sys.argv[2])
