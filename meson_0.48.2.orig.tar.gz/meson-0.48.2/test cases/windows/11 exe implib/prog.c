#include <windows.h>

int  __declspec(dllexport)
main(int argc, char **argv) {
    return 0;
}
