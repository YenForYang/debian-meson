/*
 * Requires a Unity build. Otherwise hidden_func is not specified.
 */
int main(int argc, char **argv) {
    return hidden_func();
}
