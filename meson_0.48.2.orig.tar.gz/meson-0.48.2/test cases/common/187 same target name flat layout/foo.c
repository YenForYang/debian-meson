int meson_test_main_foo(void) { return 10; }
