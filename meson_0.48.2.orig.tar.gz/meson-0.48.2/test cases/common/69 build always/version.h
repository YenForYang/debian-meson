#pragma once

const char *version_string;
