int funca();
int funcb();
int funcc();

int main(int argc, char **argv) {
    return funca() + funcb() + funcc();
}
