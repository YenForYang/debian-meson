#include <string.h>
#include <config5.h>

int main(int argc, char **argv) {
    return strcmp(MESSAGE, "@var2@");
}
