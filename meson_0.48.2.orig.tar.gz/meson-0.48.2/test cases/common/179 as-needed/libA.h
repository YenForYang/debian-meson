#include "config.h"

namespace meson_test_as_needed {
  DLL_PUBLIC extern bool linked;
}
