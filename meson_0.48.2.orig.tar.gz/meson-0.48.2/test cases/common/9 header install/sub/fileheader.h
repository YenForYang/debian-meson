#pragma once

#define LIFE "Is life! Na naa, naa-na na."
