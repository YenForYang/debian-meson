#pragma once

int entity_func1();
int entity_func2();
