#include<entity.h>

int entity_func2() {
    return 9;
}
