#include<stdio.h>

int main(int argc, char **argv) {
    printf("I am test sub2.\n");
    return 0;
}
