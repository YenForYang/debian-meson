#include<stdio.h>

int main(int argc, char **argv) {
    printf("I am test exe1.\n");
    return 0;
}
