#include"bob.h"

int main(int argc, char **argv) {
    return hidden_function();
}
